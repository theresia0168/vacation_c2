#include <windows.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>

void scan_dir(char *path, HWND list, char *keyword, HWND window){
	DIR *d;
	struct dirent *ent;
	struct stat st;
	char buf[256];
	
	d = opendir(path);
	
	while((ent = readdir(d)) != NULL){
		if((strcmp(ent->d_name, ".")==0)||(strcmp(ent->d_name, "..")==0))
			continue;
		
		sprintf(buf, "%s/%s", path, ent->d_name);
		stat(buf, &st);
		if(S_ISDIR(st.st_mode)){
			scan_dir(buf, list, keyword, window);
		}
		else if(S_ISREG(st.st_mode)){
			if(strcmp(strchr(ent->d_name, '.'), keyword) == 0){
				SendMessage(list, LB_ADDSTRING, (WPARAM)NULL, (LPARAM)buf);
			}
		}
	}
	
	closedir(d);
}

void delete_dir(char *path, HWND list, char *keyword, HWND window){
	DIR *d;
	struct dirent *ent;
	struct stat st;
	char buf[256];
	
	d = opendir(path);
	
	while((ent = readdir(d)) != NULL){
		if((strcmp(ent->d_name, ".")==0)||(strcmp(ent->d_name, "..")==0))
			continue;
		
		sprintf(buf, "%s/%s", path, ent->d_name);
		stat(buf, &st);
		if(S_ISDIR(st.st_mode)){
			delete_dir(buf, list, keyword, window);
		}
		else if(S_ISREG(st.st_mode)){
			if(strcmp(strchr(ent->d_name, '.'), keyword) == 0){
				remove(buf);
			}
		}
	}
	
	closedir(d);
}

#ifndef __SRCDST_H__
#define __SRCDST_H__

#include <windows.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>

void scan_dir(char *path, HWND list, char *keyword, HWND window);
void delete_dir(char *path, HWND list, char *keyword, HWND window);

#endif

#include <windows.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include "srcdst.h"

HWND hwnd_edit1, hwnd_listbox1, hwnd_listbox2;
HWND hwnd_button1, hwnd_button2;

/* This is where all the input to the window goes to */
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		
		/* Upon destruction, tell the main thread to stop */
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		
		case WM_CREATE:{
			//MessageBox(hwnd, "Window CREATE!","WM_CREATE!",MB_ICONEXCLAMATION|MB_OK);
			hwnd_edit1 = CreateWindow("EDIT", "", WS_VISIBLE|WS_CHILD|WS_BORDER, 5, 30, 180, 25, hwnd, NULL, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);			// �Է� �޴� â 
			hwnd_button1 = CreateWindow("BUTTON", "SEARCH", WS_VISIBLE|WS_CHILD, 190, 30, 90, 25, hwnd, NULL, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);				// OK ��ư 
			hwnd_listbox1 = CreateWindow("LISTBOX", "", WS_VISIBLE|WS_CHILD|WS_BORDER, 5, 60, 180, 370, hwnd, NULL, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL); 	// ���� ��� 
			hwnd_button2 = CreateWindow("BUTTON", "DELETE", WS_VISIBLE|WS_CHILD, 190, 220, 90, 25, hwnd, NULL, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);		// DELETE ��ư 
			CreateWindow("STATIC", "Type the file extension name you want to search, or delete", WS_VISIBLE|WS_CHILD, 5, 5, 380, 20, hwnd, NULL, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);
			CreateWindow("STATIC", "Deleted Files", WS_VISIBLE|WS_CHILD, 480, 40, 90, 15, hwnd, NULL, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);
			hwnd_listbox2 = CreateWindow("LISTBOX", "", WS_VISIBLE|WS_CHILD|WS_BORDER, 435, 60, 180, 370, hwnd, NULL, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);	// DELETE ��� 
			break;
		}
		
		case WM_COMMAND:{
			WORD h_word, l_word;
			HWND hwnd_caller;
			char edit_buffer[100];
			
			h_word = HIWORD(wParam);
			l_word = LOWORD(wParam);
			
			hwnd_caller = (HWND)lParam;
			
			if(h_word == BN_CLICKED){
				//1. edit���� Ȯ���� ���ڿ� ������ ����
				//2. scan_dir �Լ��� ���ļ� (������ Ȯ���� ���) ���� ������ ����
				//	- ������ Ȯ���� ���
				//	- ���� �߽߰� listbox1�� ��� �߰�
				 
				//SendMessage(___message which get the hwnd___, WM_GETTEXT, )
				if(hwnd_caller == hwnd_button1){
					SendMessage(hwnd_edit1, WM_GETTEXT, (WPARAM)100, (LPARAM)edit_buffer);
					scan_dir(".", hwnd_listbox1, edit_buffer, hwnd);
					MessageBox(hwnd, "Searching Complete","SEARCH",MB_ICONEXCLAMATION|MB_OK);
				}	
				if(hwnd_caller == hwnd_button2){
					SendMessage(hwnd_edit1, WM_GETTEXT, (WPARAM)100, (LPARAM)edit_buffer);
					delete_dir(".", hwnd_listbox1, edit_buffer, hwnd);
					MessageBox(hwnd, "Deleting Complete","DELETE",MB_ICONEXCLAMATION|MB_OK);
				}	
			}
			break;
		}
		
		/* All other messages (a lot of them) are processed using default procedures */
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

/* The 'main' function of Win32 GUI programs: this is where execution starts */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	WNDCLASSEX wc; /* A properties struct of our window */
	HWND hwnd; /* A 'HANDLE', hence the H, or a pointer to our window */
	MSG msg; /* A temporary location for all messages */

	/* zero out the struct and set the stuff we want to modify */
	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc; /* This is where we will send messages to */
	wc.hInstance	 = hInstance;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	
	/* White, COLOR_WINDOW is just a #define for a system color, try Ctrl+Clicking it */
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszClassName = "WindowClass";
	wc.hIcon		 = LoadIcon(NULL, IDI_APPLICATION); /* Load a standard icon */
	wc.hIconSm		 = LoadIcon(NULL, IDI_APPLICATION); /* use the name "A" to use the project icon */

	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","SEARCH & DELETE",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, /* x */
		CW_USEDEFAULT, /* y */
		640, /* width */
		480, /* height */
		NULL,NULL,hInstance,NULL);

	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	/*
		This is the heart of our program where all input is processed and 
		sent to WndProc. Note that GetMessage blocks code flow until it receives something, so
		this loop will not produce unreasonably high CPU usage
	*/
	while(GetMessage(&msg, NULL, 0, 0) > 0) { /* If no error is received... */
		TranslateMessage(&msg); /* Translate key codes to chars if present */
		DispatchMessage(&msg); /* Send it to WndProc */
	}
	return msg.wParam;
}

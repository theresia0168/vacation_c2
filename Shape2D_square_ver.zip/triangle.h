#ifndef __TRIANGLE_H__
#define __TRIANGLE_H__
#include "Shape2D.h"

class triangle: public shape2d{
	protected:
		double height, base;
	public:
		void set(double a, double b);
		double area();
		void print();
};

#endif

#ifndef __COLUMN_H__
#define __COLUMN_H__
#include "Shape2D.h"

class column{
	private:
		double height;
		shape2d *bottomShape;
	public:
		void setBottom(shape2d *s);
		void setHeight(double h);
		double volume();
};

#endif

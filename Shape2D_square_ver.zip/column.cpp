#include "Shape2D.h"
#include "column.h"

void column::setBottom(shape2d *s){
	bottomShape = s;
}

void column::setHeight(double h){
	height = h;
}

double column::volume(){
	return bottomShape->area()*height;
}

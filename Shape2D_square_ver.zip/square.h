#ifndef __SQUARE_H__
#define __SQUARE_H__
#include "Shape2D.h"
#include "triangle.h"

class square: public triangle{
	private:
		double width;
	public:
		square(double a, double b);
		double area();
};

#endif

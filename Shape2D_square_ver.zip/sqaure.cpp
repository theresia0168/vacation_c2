#include "triangle.h"
#include "square.h"

square::square(double a, double b){
	width = a;
	height = b;
}

double square::area(){
	return width*height;
}

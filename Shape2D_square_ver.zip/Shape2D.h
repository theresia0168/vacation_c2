#ifndef __SHAPE2D_H__
#define __SHAPE2D_H__
#include <stdlib.h>
#include <string>

using namespace std;

class shape2d{
	protected:
		string descrString;
	public:
		shape2d();
		shape2d(char *s);
		virtual double area();
		void print();
};

#endif

#include <iostream>
#include <string.h>
#include "Shape2D.h"
#include "triangle.h"
#include "square.h"
#include "column.h"

using namespace std;

int main(int argc, char **argv) {
	shape2d myshape("shape1");
	myshape.print();
	
	triangle mytriangle;
	mytriangle.set(10.0, 5.0);
	cout<<"tri : "<<mytriangle.area()<<endl;
	cout<<"tri : ";
	mytriangle.print();
	
	square mysquare(10.0, 5.0);
	cout<<"sq : "<<mysquare.area()<<endl;
	
	column mycol;
	mycol.setBottom((shape2d*)&mysquare);
	mycol.setHeight(10.0);
	cout<<"col : "<<mycol.volume()<<endl;
	
	/*
	string s1("hello"), s2, s3("world"), s4(" ");
	
	cout<<s1.size()<<endl;				// strlen
	cout<<s1.find('e', 0)<<endl;		// strchr, ��ȯ���� �ε��� 
	cout<<s1.find("lo", 1)<<endl; 		// strstr, ��ȯ���� �ε��� 
	cout<<s1.substr(1, 3)<<endl;		// strncpy
	cout<<s1.compare("hello")<<endl;	// strcmp
	
	s2 = s1;
	cout<<s2<<endl;
	
	s2 = s1 + s4 + s3;
	cout<<s2<<endl;
	*/
	return 0;
}

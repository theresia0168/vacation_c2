#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "Shape2D.h"
using namespace std;

shape2d::shape2d(){
	cout<<"Shape2d : "<<descrString<<endl;
}

shape2d::shape2d(char *s){
	descrString = string(s);
}

double shape2d::area(){
	cout<<"**** shape2d::area ****"<<endl;
	return 0.0;
}
		
void shape2d::print(){
	cout<<"Shape2d : "<<descrString<<endl;
}

#include <iostream>
#include "Shape2D.h"
#include "triangle.h"

using namespace std;

void triangle::set(double a, double b){
	height = a;
	base = b;
}

double triangle::area(){
	cout<<"**** triangle::area ****"<<endl;
	return height*base*0.5;
}

void triangle::print(){
}

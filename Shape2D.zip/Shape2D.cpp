#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "Shape2D.h"
using namespace std;

shape2d::shape2d(char *s){
	descrString = string(s);
}
		
void shape2d::print(){
	cout<<"Shape2d : "<<descrString<<endl;
}

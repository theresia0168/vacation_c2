#include <iostream>
#include <string.h>
#include "Shape2D.h"

using namespace std;

int main(int argc, char *argv[]) {
	shape2d myshape("shape1");
	
	myshape.print();
	
	/*
	string s1("hello"), s2, s3("world"), s4(" ");
	
	cout<<s1.size()<<endl;				// strlen
	cout<<s1.find('e', 0)<<endl;		// strchr, ��ȯ���� �ε��� 
	cout<<s1.find("lo", 1)<<endl; 		// strstr, ��ȯ���� �ε��� 
	cout<<s1.substr(1, 3)<<endl;		// strncpy
	cout<<s1.compare("hello")<<endl;	// strcmp
	
	s2 = s1;
	cout<<s2<<endl;
	
	s2 = s1 + s4 + s3;
	cout<<s2<<endl;
	*/
	return 0;
}

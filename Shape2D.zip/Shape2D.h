#ifndef __SHAPE2D_H__
#define __SHAPE2D_H__
#include <stdlib.h>
#include <string.h>

using namespace std;

class shape2d{
	private:
		string descrString;
	public:
		shape2d(char *s);
		void print();
};

#endif

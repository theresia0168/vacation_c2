#include <iostream>
#include "point.h"
using namespace std;

void point::set(int a, int b)
{
	x = a;
	y = b;
}

void point::print()
{
	cout<<"X : "<<x<<", Y : "<<y<<endl;
}

#include <iostream>
#include "point.h"
using namespace std;

point::point(){
	cout<<"POINT CONST."<<endl;
}

point::~point(){
	cout<<"POINT DEST."<<endl;
}

int main(int argc, char** argv) {
	point mypoint;
	
	mypoint.set(100, 200);
	mypoint.print();
	
	return 0;
}

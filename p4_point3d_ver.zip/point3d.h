#ifndef __POINT3D_H__
#define __POINT3D_H__
#include "point.h"

class point3d: public point{
	private:
		int z;
	public:
		point3d();
		point3d(int a, int b, int c);	// const, overloading
		~point3d();
		void set(int a, int b, int c);	// method overriding , parent - kid
		void print();					// method overloading
		void print(int n);
};

#endif

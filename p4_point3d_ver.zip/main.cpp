#include <iostream>
#include "point.h"
#include "point3d.h"
using namespace std;

int main(int argc, char** argv) {
	
	//point3d mypoint; // point3d : point class�κ��� ���
	point3d mypoint2(100,200,300);
	
	//mypoint.set(10,20,30);
	//mypoint.print();
	
	mypoint2.print();
	mypoint2.print(100);
	 
	/*
	point mypoint;
	
	mypoint.set(100, 200);
	mypoint.print();
	*/
	return 0;
}

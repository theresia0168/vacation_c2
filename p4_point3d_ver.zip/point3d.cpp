#include <iostream>
#include "point3d.h"
using namespace std;

point3d::point3d(){
	cout<<"POINT3d-CONST."<<endl;
}

point3d::point3d(int a, int b, int c){
	cout<<"POINT3d-CONST.V2"<<endl;
	set(a,b,c);	
}

point3d::~point3d(){
	cout<<"POINT3d-DEST."<<endl;
}

void point3d::set(int a, int b, int c){
	x = a;
	y = b;
	z = c;
}

void point3d::print()
{
	cout<<"X : "<<x<<", Y : "<<y<<", Z : "<<z<<endl;
}

void point3d::print(int n){
	cout<<"POINT3d : "<<x-n<<", "<<y-n<<", "<<z-n<<endl;
}
